package com.althea.ninjabot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = 0xFF100B19.toInt()
        val purple = 0xFF9B62E8.toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "ALTHEA\nNINJABRAIN BOT"
            textSize = 25f
            setTextColor(0xFFF4E9FF.toInt())
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Mini floating window untuk Minecraft Java speedrun.\n\nIzinkan tampil di atas aplikasi lain, lalu buka Minecraft dan gunakan jendela ALTHEA."
            textSize = 14f
            setTextColor(0xFFCBBBD9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 24)
        }
        val permission = Button(this).apply {
            text = "IZINKAN FLOATING WINDOW"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(i)
                } else startOverlay()
            }
        }
        val launch = Button(this).apply {
            text = "TAMPILKAN JENDELA ALTHEA"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startOverlay()
                else {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(i)
                }
            }
        }
        layout.addView(title)
        layout.addView(desc)
        layout.addView(permission)
        layout.addView(launch)
        setContentView(layout)
    }

    private fun startOverlay() {
        startService(Intent(this, OverlayService::class.java))
        finish()
    }
}
