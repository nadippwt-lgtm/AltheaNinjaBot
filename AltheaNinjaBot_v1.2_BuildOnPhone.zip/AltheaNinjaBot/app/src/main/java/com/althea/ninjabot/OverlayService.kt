package com.althea.ninjabot

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private var first: Observation? = null

    data class Observation(val x: Double, val z: Double, val yaw: Double)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_STICKY
    }

    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val purple = 0xFF9B62E8.toInt()
        val dark = 0xFF191222.toInt()
        val white = 0xFFF5EDFF.toInt()
        val muted = 0xFFD0C0E0.toInt()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(13, 10, 13, 12)
            setBackgroundColor(dark)
        }
        val header = TextView(this).apply {
            text = "✦ ALTHEA  •  STRONGHOLD  [geser]"
            textSize = 13f
            setTextColor(white)
            setPadding(4, 5, 4, 12)
        }
        val x = input("Posisi X pemain")
        val z = input("Posisi Z pemain")
        val yaw = input("Yaw saat lempar (°)")
        val result = TextView(this).apply {
            text = if (first == null) "Lemparan 1: masukkan X, Z, yaw." else "Lemparan 1 tersimpan. Masukkan lemparan 2."
            textSize = 12f
            setTextColor(muted)
            setPadding(2, 10, 2, 10)
        }
        val save = Button(this).apply {
            text = "SIMPAN LEMPARAN / HITUNG"
            setOnClickListener {
                val xx = x.text.toString().toDoubleOrNull()
                val zz = z.text.toString().toDoubleOrNull()
                val aa = yaw.text.toString().toDoubleOrNull()
                if (xx == null || zz == null || aa == null) {
                    result.text = "Isi X, Z, dan yaw dengan angka yang valid."
                    return@setOnClickListener
                }
                val obs = Observation(xx, zz, aa)
                if (first == null) {
                    first = obs
                    result.text = "Lemparan 1 tersimpan ✓\nPindah posisi, lalu isi data lemparan 2."
                    save.text = "HITUNG DARI LEMPARAN 2"
                } else {
                    val a = first!!
                    val answer = triangulate(a, obs)
                    result.text = answer
                    first = null
                    save.text = "SIMPAN LEMPARAN 1"
                }
            }
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val reset = Button(this).apply {
            text = "TUTUP"
            setOnClickListener { stopSelf() }
        }
        val minimize = Button(this).apply {
            text = "MINIMIZE"
            setOnClickListener {
                val compact = x.visibility == View.GONE
                val visibility = if (compact) View.VISIBLE else View.GONE
                x.visibility = visibility
                z.visibility = visibility
                yaw.visibility = visibility
                save.visibility = visibility
                result.visibility = visibility
                reset.visibility = visibility
                text = if (compact) "MINIMIZE" else "EXPAND"
            }
        }
        controls.addView(minimize, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        controls.addView(reset, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(header)
        box.addView(x)
        box.addView(z)
        box.addView(yaw)
        box.addView(save)
        box.addView(result)
        box.addView(controls)

        params = WindowManager.LayoutParams(
            290, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20; y = 100
        }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).roundToInt()
                    params.y = startY + (event.rawY - touchY).roundToInt()
                    wm.updateViewLayout(box, params)
                    true
                }
                else -> true
            }
        }
        panel = box
        wm.addView(box, params)
    }

    private fun input(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        textSize = 13f
        setSingleLine(true)
        setTextColor(0xFFFFFFFF.toInt())
        setHintTextColor(0xFFBBAACB.toInt())
        setPadding(8, 2, 8, 2)
    }

    private fun triangulate(a: Observation, b: Observation): String {
        val r1 = Math.toRadians(a.yaw); val r2 = Math.toRadians(b.yaw)
        val d1x = -kotlin.math.sin(r1); val d1z = kotlin.math.cos(r1)
        val d2x = -kotlin.math.sin(r2); val d2z = kotlin.math.cos(r2)
        fun cross(ax: Double, az: Double, bx: Double, bz: Double) = ax * bz - az * bx
        val den = cross(d1x, d1z, d2x, d2z)
        if (kotlin.math.abs(den) < 1e-7) return "Arah lemparan terlalu sejajar. Ambil pengamatan dari posisi lain."
        val dx = b.x - a.x; val dz = b.z - a.z
        val t1 = cross(dx, dz, d2x, d2z) / den
        val t2 = cross(dx, dz, d1x, d1z) / den
        val sx = a.x + t1 * d1x; val sz = a.z + t1 * d1z
        val warning = if (t1 < 0 || t2 < 0) "\nPeriksa yaw/koordinat: titik ada di belakang arah lemparan." else ""
        return "PERKIRAAN STRONGHOLD\nX: ${sx.roundToInt()}   Z: ${sz.roundToInt()}$warning"
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}
