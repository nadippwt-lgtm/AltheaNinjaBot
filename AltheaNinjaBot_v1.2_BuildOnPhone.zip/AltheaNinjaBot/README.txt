ALTHEA NINJABRAIN BOT - Android project v1.2

BUILD APK TANPA PC (PAKAI HP):
1. Buat/login akun GitHub lewat browser HP.
2. Buat repository baru, misalnya "AltheaNinjaBot".
3. Upload seluruh isi folder project ZIP ini ke repository (termasuk folder .github).
   Pastikan file settings.gradle, build.gradle, gradle.properties, dan folder app berada di root repository.
4. Buka tab Actions di repository.
5. Pilih workflow "Build ALTHEA NinjaBot APK".
6. Tekan "Run workflow" dan tunggu sampai selesai.
7. Buka hasil run yang sukses, cari bagian Artifacts, lalu download "ALTHEA-NinjaBot-debug".
8. Ekstrak artifact ZIP dan install app-debug.apk di Android.
9. Jika Android meminta izin instalasi dari sumber tersebut, izinkan untuk browser/file manager yang digunakan.

BUILD APK DENGAN ANDROID STUDIO:
1. Buka folder project di Android Studio.
2. Tunggu Gradle Sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

FITUR:
- Android native Kotlin.
- Floating overlay dapat digeser lewat bar judul.
- MINIMIZE / EXPAND dan TUTUP.
- Input X, Z, yaw Minecraft.
- Simpan pengamatan pertama dan hitung triangulasi dari pengamatan kedua.

CATATAN:
- ZIP ini adalah source project, bukan APK siap instal.
- Workflow GitHub Actions membangun APK debug di cloud, jadi tidak perlu PC.
- Kalkulator memakai yaw Minecraft: 0 = selatan (+Z), -90 = timur (+X), 90 = barat (-X), ±180 = utara (-Z).
- Ini triangulasi dasar, belum implementasi penuh Ninjabrain Bot (belum ada estimasi error/pixel, kalibrasi screenshot, atau prediksi stronghold ring).
